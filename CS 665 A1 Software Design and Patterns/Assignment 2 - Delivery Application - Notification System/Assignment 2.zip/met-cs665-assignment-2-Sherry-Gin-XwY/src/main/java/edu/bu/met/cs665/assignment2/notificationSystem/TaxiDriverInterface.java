package edu.bu.met.cs665.assignment2.notificationSystem;

interface TaxiDriverInterface {
    void response(Shop shop);
}
