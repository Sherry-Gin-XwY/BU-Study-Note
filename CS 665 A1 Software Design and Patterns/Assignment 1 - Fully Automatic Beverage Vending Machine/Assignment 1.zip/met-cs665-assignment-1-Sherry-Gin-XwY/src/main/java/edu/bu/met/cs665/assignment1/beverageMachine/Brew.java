package edu.bu.met.cs665.assignment1.beverageMachine;

public class Brew {
/*
    public Brew(Drink drink, DrinkType drinkType) {
        this.drink = drink;
        this.drinkType = drinkType;
    }

    private Drink drink;
    private DrinkType drinkType;
    public int sugarUnit;
    public int milkUnit;
    public int teaBag;

    public Drink getDrink() {
        return drink;
    }

    public DrinkType getDrinkType() {
        return drinkType;
    }

    public void brewCoffee(int sugarUnit, int milkUnit) throws Exception {
        try {
            if (sugarUnit > 3) {
                throw new Exception("no more than 3 unit sugar");
            }
            if (milkUnit > 3) {
                throw new Exception("no more than 3 unit milk");
            }
            if (sugarUnit + milkUnit > 6) {
                throw new Exception("sugar and milk should totally less than 6");
            }
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException("Illegal element");
        }
        this.sugarUnit = sugarUnit;
        this.milkUnit = milkUnit;
    }
 */

}
