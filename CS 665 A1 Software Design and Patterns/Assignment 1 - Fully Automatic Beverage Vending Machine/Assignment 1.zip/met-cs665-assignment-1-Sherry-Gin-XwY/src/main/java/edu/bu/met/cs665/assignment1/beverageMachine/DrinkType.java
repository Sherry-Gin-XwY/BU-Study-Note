package edu.bu.met.cs665.assignment1.beverageMachine;


// Create the DrinkType enumeration
public enum DrinkType {
    COFFEE,
    TEA
}
