<!DOCTYPE HTML>
<html>
    <head>
        <meta charset = "utf-8" />
        <title>Add a Student to XML file</title>
    </head>
    <body>
        <h1>Add a Student</h1>
        <form action="insert.php" method="post">
            First Name: <input type="test" name="firstName" id="firstName"><br>
            Last Name: <input type="test" name="lastName" id="lastName"><br>
            <input type="submit" name="submit" id="submit" value="Submit">
        </form>
    </body>
</html>