const data = require('./zips.json');

module.exports.lookupByZipCode =  (zip) => {
		
};

module.exports.lookupByCityState = (city, state) => {
		
};

module.exports.getPopulationByState = (state) => {
		
};

