const cities = require('./zipCodeModule_v1');
const colors = require('colors');



