<?php
require_once('database.php');

// Delete the student from the database


// Display the Home page
include('index.php');