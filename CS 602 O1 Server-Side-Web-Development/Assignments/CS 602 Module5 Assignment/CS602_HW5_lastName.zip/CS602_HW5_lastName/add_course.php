<?php
    require_once('database.php');

// Get the course form data


    // Add the course to the database  
   
   
    // Display the Course List page
    include('course_list.php');
}
?>