<?php
    
    require_once('database.php');

// Get the student form data


// Add the student to the database  



    // Display the Student List page
    include('index.php');

?>