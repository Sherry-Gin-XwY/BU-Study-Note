module.exports = (req , res , next) => {

	// Fill in the code

	res.render('addEmployeeView',
		{title: "Add a new employee"});

};
